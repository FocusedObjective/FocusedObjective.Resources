============================
  KanbanSim and ScrumSim
  by Focused Objective
============================


-------------------------------------------------
Installation / Unzipping
-------------------------------------------------

This software doesn't require 'installation' onto a machine, 
but the supplied .zip file needs to be extracted locally to run.

1. Open My Computer, and then locate the compressed folder.
2. Right-click the compressed folder, and then click Extract All. 
   In the Compressed (zipped) Folders Extraction Wizard, specify 
   where you want to store the extracted files.

PRE-REQUISITE - .NET 4 Framework from Microsoft -

Often this will already be installed, but if this software
failes to run, this is the most common cause.

Follow the instructions here -

http://www.microsoft.com/en-us/download/details.aspx?id=17851

OR

http://www.microsoft.com/en-us/download/details.aspx?id=17718

-------------------------------------------------
GETTING HELP
-------------------------------------------------

Email: support@focusedobjective.com
Web: support.focusedobjective.com
Twitter: @AgileSimulation

*Please follow our Twitter* account so that you can
be informmed of any known issues and updates as soon
as we know them.

-------------------------------------------------
To contact us, and for further information go to:
http://www.focusedobjective.com
-------------------------------------------------
FAQ -

Q. What does the Kanban and Scrum Simulator do?
A. Focused Objective's Kanban Simulator performs both visualizations and detailed statistical 
   analysis of software development projects based on a model you define.

Q. How does it improve the software development process?
A. Simulation gives a much deeper understanding of what factors are most influencing the delivery 
   date and throughput of a team. By embracing that estimates have varying degrees of confidence, 
   and that: defects, scope-creep, refactoring and blocking events are a fact of life, the 
   computed results carry more integrity than fixed allowances for exceptional occurrences.

Q. What does the model need to know in order to simulate?
A. The minimum data required to simulate a model is -
   1. ForKanban: The Kanban columns, WIP limits, a low-bound and high-bound cycle time estimate for each column. 
      For Scrum: The velocity range for each iteration, and how many days to an iteration.
   2. Defect categories if there are any
   3. Blocking events if there are any
   4. Added scope events if there are any
   5. A backlog, or a number of stories that make up the backlog
   
Q. Is it accurate?
A. Yes. The mathematics behind the model is sound. The age old rule of garbage-in equals garbage 
   out still applies, but the process accouns for this by looking at the statistical spread of 
   results, and helps you understand what model parameters are most important to improve accuracy. 
   For example, at the start of a project its ok for a column cycle time to be from 1 day to 5 days;
   however, if this variability causes the most influence on predicted releast date, you might 
   analyze historical data more thoroughly and tighten the range. You might also add or remove 
   defects, added scope or blocking events over the course of a project to better represent reality.

Q. The software has stopped simulating and says "License expired." What can I do?
A. We are offering a free beta version at the moment. There will always be a free version
   but whilst we are in beta we limit each license to a fixed date to ensure you are running
   the most stable version. See focusedobjective.com for the latest information.